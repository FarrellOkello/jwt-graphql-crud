import "reflect-metadata";
import "dotenv/config"
import { createConnection } from "typeorm";
import { buildSchema } from "type-graphql";
// import {User} from "./entity/User";
import { BookResolver } from "./resolvers/BookResolver";
import { UserResolver } from "./resolvers/UserResolver";
// import { ApolloServer } from "apollo-server-express"
import { _passport } from "./passport_config"
const express = require('express')
const graphqlHTTP = require('express-graphql').graphqlHTTP;
const graphql = require('graphql')
// const cors = 'cors';
// app.use(cors())


async function main() {
  const conn = await createConnection();
  const schema = await buildSchema({ resolvers: [BookResolver,UserResolver] });

  const app = express();
  app.use(_passport())
  
  app.get("/",(_req,res)=>{res.send("hello world of ooz!")})

  app.post("/refresh_token", req=>{
    console.log(req.headers);
  });  

  app.use('/api', graphqlHTTP({
  schema: schema, 
  graphiql: true,
  context: ({req,res}) => ({req,res})
  
  }));



  console.log(process.env.ACCESS_TOKEN_SECRET)
  console.log(process.env.ACCESS_TOKEN_SECRET)
   
   app.listen(4000);
  console.log("Server has started @4000!");
}

main();


