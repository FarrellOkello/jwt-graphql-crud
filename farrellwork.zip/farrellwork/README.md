# TypeGraphQL & TypeORM Example

How To Build a GraphQL API with TypeGraphQL and TypeORM. Read the [article](https://blog.logrocket.com/how-build-graphql-api-typegraphql-typeorm/).

**How to use:**

```
$ npm install
$ npm run start
```
